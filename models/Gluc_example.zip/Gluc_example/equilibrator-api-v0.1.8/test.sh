python3 -m unittest discover equilibrator_api/tests
